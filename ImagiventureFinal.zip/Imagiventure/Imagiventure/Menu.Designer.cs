﻿namespace Imagiventure
{
    partial class Menu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnPlay = new Button();
            label1 = new Label();
            button2 = new Button();
            panel1 = new Panel();
            SuspendLayout();
            // 
            // btnPlay
            // 
            btnPlay.FlatAppearance.BorderColor = Color.Black;
            btnPlay.FlatStyle = FlatStyle.Flat;
            btnPlay.Location = new Point(12, 118);
            btnPlay.Name = "btnPlay";
            btnPlay.Size = new Size(106, 27);
            btnPlay.TabIndex = 0;
            btnPlay.Text = "PLAY";
            btnPlay.UseVisualStyleBackColor = true;
            btnPlay.Click += btnPlay_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(12, 18);
            label1.Name = "label1";
            label1.Size = new Size(157, 31);
            label1.TabIndex = 1;
            label1.Text = "Imagiventure";
            // 
            // button2
            // 
            button2.FlatAppearance.BorderColor = Color.Black;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Location = new Point(12, 164);
            button2.Name = "button2";
            button2.Size = new Size(106, 27);
            button2.TabIndex = 2;
            button2.Text = "QUIT";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaptionText;
            panel1.Location = new Point(12, 52);
            panel1.Name = "panel1";
            panel1.Size = new Size(200, 10);
            panel1.TabIndex = 3;
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(291, 488);
            Controls.Add(panel1);
            Controls.Add(button2);
            Controls.Add(label1);
            Controls.Add(btnPlay);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Menu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnPlay;
        private Label label1;
        private Button button2;
        private Panel panel1;
    }
}