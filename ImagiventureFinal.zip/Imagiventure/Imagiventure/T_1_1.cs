﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Imagiventure
{



    public partial class T_1_1 : Form
    {
        //Life
        int chances = 10;
        int t4_player_score = 0;
        int t4_dragon_score = 0;

        //Answers
        String t1_answer_key = "BOOK";
        String[] attacks = { "Rock", "Paper", "Scissor" };
        String t5_answer_key = "DREAM";
        //Others
        int random_num;


        public T_1_1()
        {
            InitializeComponent();
        }

        private void T_1_1_Load(object sender, EventArgs e)
        {
            lbl_t3_answer.Hide();
            lbl_t3_answer2.Hide();
            btn_t3_next.Hide();

            player_score.Text = t4_player_score.ToString();
            dragon_score.Text = t4_dragon_score.ToString();

            lblChances.Text = chances.ToString();
            random_num = RandomNumberGenerator();
            Debug.WriteLine("The random number is " + random_num);
            Console.WriteLine("The random number is " + random_num);
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            if (t1_answer.Text.ToUpper().Equals(t1_answer_key))
            {
                trial_board.SelectedTab = trial_2;
            }
            else
            {
                if (chances == 0)
                {
                    MessageBox.Show("Game Over! You are not a true hero!");
                    Menu m = new Menu();
                    m.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Wrong! Try some other answer young hero...");
                    DeductChances();
                }
                
            }

        }


        private void btn_sub_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.Parse(t2_answer.Text) == 0)
                {
                    lbl_comment.Text = "I said numbers 1-10 only";
                }
                else
                {
                    CheckNumber(int.Parse(t2_answer.Text));
                }
            }
            catch (FormatException ee)
            {
                MessageBox.Show("Make it sure it is a number.");
                DeductChances();
            }


        }

        public int RandomNumberGenerator()
        {
            Random rnd = new Random();
            int randomNumber = rnd.Next(1, 10);
            return randomNumber;
        }
        public void CheckNumber(int answer)
        {

            if (answer == random_num)
            {
                lbl_comment.Text = "Marvelous!";
                
                trial_board.SelectedTab = trial_3;
            }
            else if (answer > random_num)
            {
                MessageBox.Show("Wrong Answer!");
                lbl_comment.Text = "Make it lower...";

                DeductChances();
            }
            else if (answer < random_num)
            {
                MessageBox.Show("Wrong Answer!");
                lbl_comment.Text = "Higher hero Higher!";
                DeductChances();
            }
            else if (answer > 10)
            {
                MessageBox.Show("Wrong Answer!");
                lbl_comment.Text = "I said numbers 1-10 only";
                DeductChances();
            }
            else
            {
                MessageBox.Show("Wrong Answer!");
                DeductChances();
            }
        }

        public void DeductChances()
        {
            chances--;
            lblChances.Text = chances.ToString();


        }

        public void GameOver()
        {
            if (chances == 0)
            {
                MessageBox.Show("Game Over! You are not a true hero!");
                Menu m = new Menu();
                m.Show();
                this.Hide();
            }
        }


        private void btn_done_Click(object sender, EventArgs e)
        {
            lbl_t3_answer.Show();
            lbl_t3_answer2.Show();
            btn_t3_next.Show();
        }



        private void btn_attack_Click(object sender, EventArgs e)
        {

            Random rnd = new Random();
            int randomNumber = rnd.Next(1, 3);
            String dragon_choice = attacks[randomNumber];

            lbl_attack.Text = cb_attacks.Text;
            dragon_attack.Text = dragon_choice;

            if (cb_attacks.Text == "Rock")
            {
                if (dragon_choice == "Rock")
                {
                    MessageBox.Show("Tie!");
                }
                else if (dragon_choice == "Paper")
                {
                    MessageBox.Show("Red Dragon Wins!");
                    t4_dragon_score++;
                    dragon_score.Text = t4_dragon_score.ToString();
                }
                else if (dragon_choice == "Scissor")
                {
                    MessageBox.Show("You Win!");
                    t4_player_score++;
                    player_score.Text = t4_player_score.ToString();
                }
            }
            else if (cb_attacks.Text == "Paper")
            {
                if (dragon_choice == "Rock")
                {
                    MessageBox.Show("You Win!");
                    t4_player_score++;
                    player_score.Text = t4_player_score.ToString();
                }
                else if (dragon_choice == "Paper")
                {
                    MessageBox.Show("Tie!");
                }
                else if (dragon_choice == "Scissor")
                {
                    MessageBox.Show("Red Dragon Wins!");
                    t4_dragon_score++;
                    dragon_score.Text = t4_dragon_score.ToString();
                }
            }
            else if (cb_attacks.Text == "Scissor")
            {
                if (dragon_choice == "Rock")
                {
                    MessageBox.Show("Red Dragon Wins!");
                    t4_dragon_score++;
                    dragon_score.Text = t4_dragon_score.ToString();
                }
                else if (dragon_choice == "Paper")
                {
                    MessageBox.Show("You Win!");
                    t4_player_score++;
                    player_score.Text = t4_player_score.ToString();
                }
                else if (dragon_choice == "Scissor")
                {
                    MessageBox.Show("Tie!");
                }
            }

            if (t4_player_score == 3)
            {
                MessageBox.Show("Splendid!");
                trial_board.SelectedTab = trial_5;
                Menu m = new Menu();
                m.Show();
                this.Hide();
            }

            if (t4_dragon_score == 3)
            {

                MessageBox.Show("Burn to Crisp! Farewell Hero *buga fire*");
                MessageBox.Show("Game Over");
                Menu m = new Menu();
                m.Show();
                this.Hide();
            }


        }

        private void btn_t3_next_Click(object sender, EventArgs e)
        {
            trial_board.SelectedTab = trial_4;
        }

        private void btn_finish_Click(object sender, EventArgs e)
        {
            if(tb_answer.Text.ToUpper() == t5_answer_key)
            {
                MessageBox.Show("Atlast you've finished your trials! Edi Wow");
                
            }
            else
            {
                if (chances == 0)
                {
                    MessageBox.Show("Game Over! You are not a true hero!");
                    Menu m = new Menu();
                    m.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Wrong answer. Try another one!");
                    DeductChances();
                }
                
               
            }
        }
    }
}
