﻿namespace Imagiventure
{
    partial class T_1_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(T_1_1));
            this.trial_board = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_submit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.t1_answer = new System.Windows.Forms.TextBox();
            this.trial_1 = new System.Windows.Forms.Label();
            this.trial_2 = new System.Windows.Forms.TabPage();
            this.lbl_comment = new System.Windows.Forms.Label();
            this.btn_sub = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.t2_answer = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.trial_3 = new System.Windows.Forms.TabPage();
            this.lbl_t3_answer2 = new System.Windows.Forms.Label();
            this.btn_t3_next = new System.Windows.Forms.Button();
            this.lbl_t3_answer = new System.Windows.Forms.Label();
            this.btn_done = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.trial_4 = new System.Windows.Forms.TabPage();
            this.btn_attack = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.cb_attacks = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.trial_5 = new System.Windows.Forms.TabPage();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblChances = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.trial_board.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.trial_2.SuspendLayout();
            this.trial_3.SuspendLayout();
            this.trial_4.SuspendLayout();
            this.trial_5.SuspendLayout();
            this.SuspendLayout();
            // 
            // trial_board
            // 
            this.trial_board.Controls.Add(this.tabPage1);
            this.trial_board.Controls.Add(this.trial_2);
            this.trial_board.Controls.Add(this.trial_3);
            this.trial_board.Controls.Add(this.trial_4);
            this.trial_board.Controls.Add(this.trial_5);
            this.trial_board.Location = new System.Drawing.Point(12, 47);
            this.trial_board.Name = "trial_board";
            this.trial_board.SelectedIndex = 0;
            this.trial_board.Size = new System.Drawing.Size(768, 351);
            this.trial_board.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btn_submit);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.t1_answer);
            this.tabPage1.Controls.Add(this.trial_1);
            this.tabPage1.Font = new System.Drawing.Font("SimSun", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(760, 323);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Trial 1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btn_submit
            // 
            this.btn_submit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_submit.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.btn_submit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_submit.Location = new System.Drawing.Point(617, 167);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(75, 34);
            this.btn_submit.TabIndex = 8;
            this.btn_submit.Text = "Submit";
            this.btn_submit.UseVisualStyleBackColor = true;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(441, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 27);
            this.label2.TabIndex = 7;
            this.label2.Text = "Answer:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // t1_answer
            // 
            this.t1_answer.Location = new System.Drawing.Point(441, 128);
            this.t1_answer.Name = "t1_answer";
            this.t1_answer.Size = new System.Drawing.Size(251, 21);
            this.t1_answer.TabIndex = 5;
            // 
            // trial_1
            // 
            this.trial_1.AutoSize = true;
            this.trial_1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.trial_1.Location = new System.Drawing.Point(27, 34);
            this.trial_1.Name = "trial_1";
            this.trial_1.Size = new System.Drawing.Size(305, 230);
            this.trial_1.TabIndex = 4;
            this.trial_1.Text = resources.GetString("trial_1.Text");
            this.trial_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // trial_2
            // 
            this.trial_2.Controls.Add(this.lbl_comment);
            this.trial_2.Controls.Add(this.btn_sub);
            this.trial_2.Controls.Add(this.label8);
            this.trial_2.Controls.Add(this.t2_answer);
            this.trial_2.Controls.Add(this.label7);
            this.trial_2.Controls.Add(this.label6);
            this.trial_2.Controls.Add(this.label5);
            this.trial_2.Controls.Add(this.label4);
            this.trial_2.Controls.Add(this.label3);
            this.trial_2.Location = new System.Drawing.Point(4, 24);
            this.trial_2.Name = "trial_2";
            this.trial_2.Padding = new System.Windows.Forms.Padding(3);
            this.trial_2.Size = new System.Drawing.Size(760, 323);
            this.trial_2.TabIndex = 1;
            this.trial_2.Text = "Trial 2";
            this.trial_2.UseVisualStyleBackColor = true;
            // 
            // lbl_comment
            // 
            this.lbl_comment.AutoSize = true;
            this.lbl_comment.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_comment.Location = new System.Drawing.Point(48, 237);
            this.lbl_comment.Name = "lbl_comment";
            this.lbl_comment.Size = new System.Drawing.Size(40, 29);
            this.lbl_comment.TabIndex = 13;
            this.lbl_comment.Text = "...";
            this.lbl_comment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_sub
            // 
            this.btn_sub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sub.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.btn_sub.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_sub.Location = new System.Drawing.Point(644, 285);
            this.btn_sub.Name = "btn_sub";
            this.btn_sub.Size = new System.Drawing.Size(75, 34);
            this.btn_sub.TabIndex = 12;
            this.btn_sub.Text = "Submit";
            this.btn_sub.UseVisualStyleBackColor = true;
            this.btn_sub.Click += new System.EventHandler(this.btn_sub_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(419, 286);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 27);
            this.label8.TabIndex = 11;
            this.label8.Text = "Answer:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // t2_answer
            // 
            this.t2_answer.Location = new System.Drawing.Point(511, 290);
            this.t2_answer.Name = "t2_answer";
            this.t2_answer.Size = new System.Drawing.Size(124, 23);
            this.t2_answer.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(376, 243);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(145, 23);
            this.label7.TabIndex = 9;
            this.label7.Text = "Start guessing...";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(532, 175);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(162, 29);
            this.label6.TabIndex = 8;
            this.label6.Text = "Numbers 1-10";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(376, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(261, 46);
            this.label5.TabIndex = 7;
            this.label5.Text = "The number that I\'m currently \r\nthinking belongs to";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(48, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(352, 46);
            this.label4.TabIndex = 6;
            this.label4.Text = "If you guess the number that I\'m thinking.\r\nI\'ll let you pass the second trial.";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(6, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(422, 69);
            this.label3.TabIndex = 5;
            this.label3.Text = "Right answer! \r\nbut Words couldn\'t be able to define you as a hero.\r\nLet\'s try so" +
    "me numbers, shall we?";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // trial_3
            // 
            this.trial_3.Controls.Add(this.lbl_t3_answer2);
            this.trial_3.Controls.Add(this.btn_t3_next);
            this.trial_3.Controls.Add(this.lbl_t3_answer);
            this.trial_3.Controls.Add(this.btn_done);
            this.trial_3.Controls.Add(this.label13);
            this.trial_3.Controls.Add(this.label12);
            this.trial_3.Controls.Add(this.label11);
            this.trial_3.Controls.Add(this.label10);
            this.trial_3.Location = new System.Drawing.Point(4, 24);
            this.trial_3.Name = "trial_3";
            this.trial_3.Padding = new System.Windows.Forms.Padding(3);
            this.trial_3.Size = new System.Drawing.Size(760, 323);
            this.trial_3.TabIndex = 2;
            this.trial_3.Text = "Trial 3";
            this.trial_3.UseVisualStyleBackColor = true;
            // 
            // lbl_t3_answer2
            // 
            this.lbl_t3_answer2.AutoSize = true;
            this.lbl_t3_answer2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_t3_answer2.Location = new System.Drawing.Point(445, 228);
            this.lbl_t3_answer2.Name = "lbl_t3_answer2";
            this.lbl_t3_answer2.Size = new System.Drawing.Size(312, 46);
            this.lbl_t3_answer2.TabIndex = 16;
            this.lbl_t3_answer2.Text = "Since you followed my instructions, \r\nyou can now proceed to the next trial.";
            this.lbl_t3_answer2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_t3_next
            // 
            this.btn_t3_next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_t3_next.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.btn_t3_next.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_t3_next.Location = new System.Drawing.Point(679, 281);
            this.btn_t3_next.Name = "btn_t3_next";
            this.btn_t3_next.Size = new System.Drawing.Size(75, 34);
            this.btn_t3_next.TabIndex = 15;
            this.btn_t3_next.Text = "Next";
            this.btn_t3_next.UseVisualStyleBackColor = true;
            // 
            // lbl_t3_answer
            // 
            this.lbl_t3_answer.AutoSize = true;
            this.lbl_t3_answer.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_t3_answer.Location = new System.Drawing.Point(494, 117);
            this.lbl_t3_answer.Name = "lbl_t3_answer";
            this.lbl_t3_answer.Size = new System.Drawing.Size(177, 30);
            this.lbl_t3_answer.TabIndex = 14;
            this.lbl_t3_answer.Text = "The answer is 2";
            this.lbl_t3_answer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_done
            // 
            this.btn_done.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_done.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.btn_done.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_done.Location = new System.Drawing.Point(6, 281);
            this.btn_done.Name = "btn_done";
            this.btn_done.Size = new System.Drawing.Size(75, 34);
            this.btn_done.TabIndex = 13;
            this.btn_done.Text = "Done";
            this.btn_done.UseVisualStyleBackColor = true;
            this.btn_done.Click += new System.EventHandler(this.btn_done_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(3, 247);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(254, 19);
            this.label13.TabIndex = 9;
            this.label13.Text = "(Click DONE if you are done thinking)";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(6, 228);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(366, 19);
            this.label12.TabIndex = 8;
            this.label12.Text = "If you are done thinking, I am going to start guessing.";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(6, 53);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(326, 161);
            this.label11.TabIndex = 7;
            this.label11.Text = resources.GetString("label11.Text");
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(6, 18);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(483, 23);
            this.label10.TabIndex = 6;
            this.label10.Text = "Excellent! This time let me be the one to guess the number.";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // trial_4
            // 
            this.trial_4.Controls.Add(this.label9);
            this.trial_4.Controls.Add(this.btn_attack);
            this.trial_4.Controls.Add(this.label26);
            this.trial_4.Controls.Add(this.label25);
            this.trial_4.Controls.Add(this.cb_attacks);
            this.trial_4.Controls.Add(this.label24);
            this.trial_4.Controls.Add(this.label23);
            this.trial_4.Controls.Add(this.label22);
            this.trial_4.Controls.Add(this.label21);
            this.trial_4.Controls.Add(this.label20);
            this.trial_4.Controls.Add(this.label19);
            this.trial_4.Controls.Add(this.label18);
            this.trial_4.Controls.Add(this.label17);
            this.trial_4.Controls.Add(this.label16);
            this.trial_4.Location = new System.Drawing.Point(4, 24);
            this.trial_4.Name = "trial_4";
            this.trial_4.Padding = new System.Windows.Forms.Padding(3);
            this.trial_4.Size = new System.Drawing.Size(760, 323);
            this.trial_4.TabIndex = 3;
            this.trial_4.Text = "Trial 4";
            this.trial_4.UseVisualStyleBackColor = true;
            // 
            // btn_attack
            // 
            this.btn_attack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_attack.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.btn_attack.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_attack.Location = new System.Drawing.Point(440, 277);
            this.btn_attack.Name = "btn_attack";
            this.btn_attack.Size = new System.Drawing.Size(75, 34);
            this.btn_attack.TabIndex = 19;
            this.btn_attack.Text = "Attack";
            this.btn_attack.UseVisualStyleBackColor = true;
            this.btn_attack.Click += new System.EventHandler(this.btn_attack_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(497, 206);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(45, 23);
            this.label26.TabIndex = 18;
            this.label26.Text = "Rock";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(219, 206);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(45, 23);
            this.label25.TabIndex = 17;
            this.label25.Text = "Rock";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cb_attacks
            // 
            this.cb_attacks.FormattingEnabled = true;
            this.cb_attacks.Items.AddRange(new object[] {
            "Rock",
            "Paper",
            "Scissor"});
            this.cb_attacks.Location = new System.Drawing.Point(235, 284);
            this.cb_attacks.Name = "cb_attacks";
            this.cb_attacks.Size = new System.Drawing.Size(199, 23);
            this.cb_attacks.TabIndex = 16;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(338, 194);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(48, 35);
            this.label24.TabIndex = 15;
            this.label24.Text = "VS";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(426, 158);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(175, 23);
            this.label23.TabIndex = 14;
            this.label23.Text = "Red Dragon\'s Attack\r\n";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(188, 158);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(105, 23);
            this.label22.TabIndex = 13;
            this.label22.Text = "Your Attack";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(168, 247);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(417, 23);
            this.label21.TabIndex = 12;
            this.label21.Text = "(Select you attack by choosing the drop down menu)";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(60, 97);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(661, 46);
            this.label20.TabIndex = 11;
            this.label20.Text = "Don\'t just think this is a normal game, remember you are still in your fourth tri" +
    "al.\r\nIf you win 3 times I\'ll let you pass, but If you fail I\'ll burn all of your" +
    " chances.";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(338, 62);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(383, 23);
            this.label19.TabIndex = 10;
            this.label19.Text = "I challenge you to a Rock, Paper, Scissor Game";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(108, 62);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(224, 23);
            this.label18.TabIndex = 9;
            this.label18.Text = "So you are the new hero...";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(6, 62);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(113, 23);
            this.label17.TabIndex = 8;
            this.label17.Text = "Red Dragon: \r\n";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(6, 21);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(212, 23);
            this.label16.TabIndex = 7;
            this.label16.Text = "*A Red Dragon appeared*";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // trial_5
            // 
            this.trial_5.Controls.Add(this.comboBox2);
            this.trial_5.Controls.Add(this.label28);
            this.trial_5.Controls.Add(this.label27);
            this.trial_5.Location = new System.Drawing.Point(4, 24);
            this.trial_5.Name = "trial_5";
            this.trial_5.Padding = new System.Windows.Forms.Padding(3);
            this.trial_5.Size = new System.Drawing.Size(760, 323);
            this.trial_5.TabIndex = 4;
            this.trial_5.Text = "Trial 5";
            this.trial_5.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Rock",
            "Paper",
            "Scissor"});
            this.comboBox2.Location = new System.Drawing.Point(361, 268);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(199, 23);
            this.comboBox2.TabIndex = 17;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(361, 232);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(193, 23);
            this.label28.TabIndex = 11;
            this.label28.Text = "Answer your final trial:";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(32, 54);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(294, 161);
            this.label27.TabIndex = 10;
            this.label27.Text = "Making every trial there\'s an end,\r\nEvery journey makes you bend.\r\nEverywhere you" +
    " should be,\r\nSeeking for the one legitimate key.\r\n\r\nStarting characters of every" +
    " trials,\r\nwill it be?\r\n";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(570, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 27);
            this.label1.TabIndex = 5;
            this.label1.Text = "Chances: ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblChances
            // 
            this.lblChances.AutoSize = true;
            this.lblChances.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblChances.Location = new System.Drawing.Point(660, 9);
            this.lblChances.Name = "lblChances";
            this.lblChances.Size = new System.Drawing.Size(36, 27);
            this.lblChances.TabIndex = 6;
            this.lblChances.Text = "10";
            this.lblChances.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(6, 276);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 35);
            this.label9.TabIndex = 20;
            this.label9.Text = "Score:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // T_1_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 410);
            this.Controls.Add(this.lblChances);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.trial_board);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "T_1_1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "T_1_1";
            this.Load += new System.EventHandler(this.T_1_1_Load);
            this.trial_board.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.trial_2.ResumeLayout(false);
            this.trial_2.PerformLayout();
            this.trial_3.ResumeLayout(false);
            this.trial_3.PerformLayout();
            this.trial_4.ResumeLayout(false);
            this.trial_4.PerformLayout();
            this.trial_5.ResumeLayout(false);
            this.trial_5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TabControl trial_board;
        private TabPage tabPage1;
        private TabPage trial_2;
        private Label label2;
        private TextBox t1_answer;
        private Label trial_1;
        private Label label1;
        private Label lblChances;
        private Button btn_submit;
        private Label lbl_comment;
        private Button btn_sub;
        private Label label8;
        private TextBox t2_answer;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private TabPage trial_3;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label lbl_t3_answer2;
        private Button btn_t3_next;
        private Label lbl_t3_answer;
        private Button btn_done;
        private TabPage trial_4;
        private Label label26;
        private Label label25;
        private ComboBox cb_attacks;
        private Label label24;
        private Label label23;
        private Label label22;
        private Label label21;
        private Label label20;
        private Label label19;
        private Label label18;
        private Label label17;
        private Label label16;
        private TabPage trial_5;
        private ComboBox comboBox2;
        private Label label28;
        private Label label27;
        private Button btn_attack;
        private Label label9;
    }
}