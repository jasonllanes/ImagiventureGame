﻿namespace Imagiventure
{
    partial class T_1_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(T_1_1));
            trial_board = new TabControl();
            tabPage1 = new TabPage();
            btn_submit = new Button();
            label2 = new Label();
            t1_answer = new TextBox();
            trial_1 = new Label();
            trial_2 = new TabPage();
            lbl_comment = new Label();
            btn_sub = new Button();
            label8 = new Label();
            t2_answer = new TextBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            trial_3 = new TabPage();
            lbl_t3_answer2 = new Label();
            btn_t3_next = new Button();
            lbl_t3_answer = new Label();
            btn_done = new Button();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            trial_4 = new TabPage();
            dragon_score = new Label();
            player_score = new Label();
            btn_attack = new Button();
            dragon_attack = new Label();
            lbl_attack = new Label();
            cb_attacks = new ComboBox();
            label24 = new Label();
            label23 = new Label();
            label22 = new Label();
            label21 = new Label();
            label20 = new Label();
            label19 = new Label();
            label18 = new Label();
            label17 = new Label();
            label16 = new Label();
            trial_5 = new TabPage();
            btn_finish = new Button();
            label28 = new Label();
            label27 = new Label();
            label1 = new Label();
            lblChances = new Label();
            tb_answer = new TextBox();
            trial_board.SuspendLayout();
            tabPage1.SuspendLayout();
            trial_2.SuspendLayout();
            trial_3.SuspendLayout();
            trial_4.SuspendLayout();
            trial_5.SuspendLayout();
            SuspendLayout();
            // 
            // trial_board
            // 
            trial_board.Controls.Add(tabPage1);
            trial_board.Controls.Add(trial_2);
            trial_board.Controls.Add(trial_3);
            trial_board.Controls.Add(trial_4);
            trial_board.Controls.Add(trial_5);
            trial_board.Location = new Point(12, 47);
            trial_board.Name = "trial_board";
            trial_board.SelectedIndex = 0;
            trial_board.Size = new Size(768, 351);
            trial_board.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(btn_submit);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(t1_answer);
            tabPage1.Controls.Add(trial_1);
            tabPage1.Font = new Font("SimSun", 9F, FontStyle.Bold, GraphicsUnit.Point);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(760, 323);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Trial 1";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // btn_submit
            // 
            btn_submit.FlatStyle = FlatStyle.Flat;
            btn_submit.Font = new Font("Comic Sans MS", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btn_submit.ForeColor = SystemColors.ActiveCaptionText;
            btn_submit.Location = new Point(617, 167);
            btn_submit.Name = "btn_submit";
            btn_submit.Size = new Size(75, 34);
            btn_submit.TabIndex = 8;
            btn_submit.Text = "Submit";
            btn_submit.UseVisualStyleBackColor = true;
            btn_submit.Click += btn_submit_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Comic Sans MS", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(441, 98);
            label2.Name = "label2";
            label2.Size = new Size(86, 27);
            label2.TabIndex = 7;
            label2.Text = "Answer:";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // t1_answer
            // 
            t1_answer.Location = new Point(441, 128);
            t1_answer.Name = "t1_answer";
            t1_answer.Size = new Size(251, 21);
            t1_answer.TabIndex = 5;
            // 
            // trial_1
            // 
            trial_1.AutoSize = true;
            trial_1.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            trial_1.Location = new Point(27, 34);
            trial_1.Name = "trial_1";
            trial_1.Size = new Size(305, 230);
            trial_1.TabIndex = 4;
            trial_1.Text = resources.GetString("trial_1.Text");
            trial_1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // trial_2
            // 
            trial_2.Controls.Add(lbl_comment);
            trial_2.Controls.Add(btn_sub);
            trial_2.Controls.Add(label8);
            trial_2.Controls.Add(t2_answer);
            trial_2.Controls.Add(label7);
            trial_2.Controls.Add(label6);
            trial_2.Controls.Add(label5);
            trial_2.Controls.Add(label4);
            trial_2.Controls.Add(label3);
            trial_2.Location = new Point(4, 24);
            trial_2.Name = "trial_2";
            trial_2.Padding = new Padding(3);
            trial_2.Size = new Size(760, 323);
            trial_2.TabIndex = 1;
            trial_2.Text = "Trial 2";
            trial_2.UseVisualStyleBackColor = true;
            // 
            // lbl_comment
            // 
            lbl_comment.AutoSize = true;
            lbl_comment.Font = new Font("Comic Sans MS", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lbl_comment.Location = new Point(48, 237);
            lbl_comment.Name = "lbl_comment";
            lbl_comment.Size = new Size(40, 29);
            lbl_comment.TabIndex = 13;
            lbl_comment.Text = "...";
            lbl_comment.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btn_sub
            // 
            btn_sub.FlatStyle = FlatStyle.Flat;
            btn_sub.Font = new Font("Comic Sans MS", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btn_sub.ForeColor = SystemColors.ActiveCaptionText;
            btn_sub.Location = new Point(644, 285);
            btn_sub.Name = "btn_sub";
            btn_sub.Size = new Size(75, 34);
            btn_sub.TabIndex = 12;
            btn_sub.Text = "Submit";
            btn_sub.UseVisualStyleBackColor = true;
            btn_sub.Click += btn_sub_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Comic Sans MS", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(419, 286);
            label8.Name = "label8";
            label8.Size = new Size(86, 27);
            label8.TabIndex = 11;
            label8.Text = "Answer:";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // t2_answer
            // 
            t2_answer.Location = new Point(511, 290);
            t2_answer.Name = "t2_answer";
            t2_answer.Size = new Size(124, 23);
            t2_answer.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(376, 243);
            label7.Name = "label7";
            label7.Size = new Size(145, 23);
            label7.TabIndex = 9;
            label7.Text = "Start guessing...";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Comic Sans MS", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label6.Location = new Point(532, 175);
            label6.Name = "label6";
            label6.Size = new Size(162, 29);
            label6.TabIndex = 8;
            label6.Text = "Numbers 1-10";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(376, 154);
            label5.Name = "label5";
            label5.Size = new Size(261, 46);
            label5.TabIndex = 7;
            label5.Text = "The number that I'm currently \r\nthinking belongs to";
            label5.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(48, 87);
            label4.Name = "label4";
            label4.Size = new Size(352, 46);
            label4.TabIndex = 6;
            label4.Text = "If you guess the number that I'm thinking.\r\nI'll let you pass the second trial.";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(6, 7);
            label3.Name = "label3";
            label3.Size = new Size(422, 69);
            label3.TabIndex = 5;
            label3.Text = "Right answer! \r\nbut Words couldn't be able to define you as a hero.\r\nLet's try some numbers, shall we?";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // trial_3
            // 
            trial_3.Controls.Add(lbl_t3_answer2);
            trial_3.Controls.Add(btn_t3_next);
            trial_3.Controls.Add(lbl_t3_answer);
            trial_3.Controls.Add(btn_done);
            trial_3.Controls.Add(label13);
            trial_3.Controls.Add(label12);
            trial_3.Controls.Add(label11);
            trial_3.Controls.Add(label10);
            trial_3.Location = new Point(4, 24);
            trial_3.Name = "trial_3";
            trial_3.Padding = new Padding(3);
            trial_3.Size = new Size(760, 323);
            trial_3.TabIndex = 2;
            trial_3.Text = "Trial 3";
            trial_3.UseVisualStyleBackColor = true;
            // 
            // lbl_t3_answer2
            // 
            lbl_t3_answer2.AutoSize = true;
            lbl_t3_answer2.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_t3_answer2.Location = new Point(445, 228);
            lbl_t3_answer2.Name = "lbl_t3_answer2";
            lbl_t3_answer2.Size = new Size(312, 46);
            lbl_t3_answer2.TabIndex = 16;
            lbl_t3_answer2.Text = "Since you followed my instructions, \r\nyou can now proceed to the next trial.";
            lbl_t3_answer2.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // btn_t3_next
            // 
            btn_t3_next.FlatStyle = FlatStyle.Flat;
            btn_t3_next.Font = new Font("Comic Sans MS", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btn_t3_next.ForeColor = SystemColors.ActiveCaptionText;
            btn_t3_next.Location = new Point(679, 281);
            btn_t3_next.Name = "btn_t3_next";
            btn_t3_next.Size = new Size(75, 34);
            btn_t3_next.TabIndex = 15;
            btn_t3_next.Text = "Next";
            btn_t3_next.UseVisualStyleBackColor = true;
            btn_t3_next.Click += btn_t3_next_Click;
            // 
            // lbl_t3_answer
            // 
            lbl_t3_answer.AutoSize = true;
            lbl_t3_answer.Font = new Font("Comic Sans MS", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_t3_answer.Location = new Point(494, 117);
            lbl_t3_answer.Name = "lbl_t3_answer";
            lbl_t3_answer.Size = new Size(177, 30);
            lbl_t3_answer.TabIndex = 14;
            lbl_t3_answer.Text = "The answer is 2";
            lbl_t3_answer.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // btn_done
            // 
            btn_done.FlatStyle = FlatStyle.Flat;
            btn_done.Font = new Font("Comic Sans MS", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btn_done.ForeColor = SystemColors.ActiveCaptionText;
            btn_done.Location = new Point(6, 281);
            btn_done.Name = "btn_done";
            btn_done.Size = new Size(75, 34);
            btn_done.TabIndex = 13;
            btn_done.Text = "Done";
            btn_done.UseVisualStyleBackColor = true;
            btn_done.Click += btn_done_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Comic Sans MS", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label13.Location = new Point(3, 247);
            label13.Name = "label13";
            label13.Size = new Size(254, 19);
            label13.TabIndex = 9;
            label13.Text = "(Click DONE if you are done thinking)";
            label13.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Comic Sans MS", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label12.Location = new Point(6, 228);
            label12.Name = "label12";
            label12.Size = new Size(366, 19);
            label12.TabIndex = 8;
            label12.Text = "If you are done thinking, I am going to start guessing.";
            label12.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label11.Location = new Point(6, 53);
            label11.Name = "label11";
            label11.Size = new Size(326, 161);
            label11.TabIndex = 7;
            label11.Text = resources.GetString("label11.Text");
            label11.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(6, 18);
            label10.Name = "label10";
            label10.Size = new Size(483, 23);
            label10.TabIndex = 6;
            label10.Text = "Excellent! This time let me be the one to guess the number.";
            label10.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // trial_4
            // 
            trial_4.Controls.Add(dragon_score);
            trial_4.Controls.Add(player_score);
            trial_4.Controls.Add(btn_attack);
            trial_4.Controls.Add(dragon_attack);
            trial_4.Controls.Add(lbl_attack);
            trial_4.Controls.Add(cb_attacks);
            trial_4.Controls.Add(label24);
            trial_4.Controls.Add(label23);
            trial_4.Controls.Add(label22);
            trial_4.Controls.Add(label21);
            trial_4.Controls.Add(label20);
            trial_4.Controls.Add(label19);
            trial_4.Controls.Add(label18);
            trial_4.Controls.Add(label17);
            trial_4.Controls.Add(label16);
            trial_4.Location = new Point(4, 24);
            trial_4.Name = "trial_4";
            trial_4.Padding = new Padding(3);
            trial_4.Size = new Size(760, 323);
            trial_4.TabIndex = 3;
            trial_4.Text = "Trial 4";
            trial_4.UseVisualStyleBackColor = true;
            // 
            // dragon_score
            // 
            dragon_score.AutoSize = true;
            dragon_score.Font = new Font("Comic Sans MS", 18F, FontStyle.Bold, GraphicsUnit.Point);
            dragon_score.ForeColor = Color.Black;
            dragon_score.Location = new Point(620, 276);
            dragon_score.Name = "dragon_score";
            dragon_score.Size = new Size(92, 35);
            dragon_score.TabIndex = 21;
            dragon_score.Text = "Score:";
            dragon_score.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // player_score
            // 
            player_score.AutoSize = true;
            player_score.Font = new Font("Comic Sans MS", 18F, FontStyle.Bold, GraphicsUnit.Point);
            player_score.ForeColor = Color.Black;
            player_score.Location = new Point(6, 276);
            player_score.Name = "player_score";
            player_score.Size = new Size(92, 35);
            player_score.TabIndex = 20;
            player_score.Text = "Score:";
            player_score.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btn_attack
            // 
            btn_attack.FlatStyle = FlatStyle.Flat;
            btn_attack.Font = new Font("Comic Sans MS", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btn_attack.ForeColor = SystemColors.ActiveCaptionText;
            btn_attack.Location = new Point(440, 277);
            btn_attack.Name = "btn_attack";
            btn_attack.Size = new Size(75, 34);
            btn_attack.TabIndex = 19;
            btn_attack.Text = "Attack";
            btn_attack.UseVisualStyleBackColor = true;
            btn_attack.Click += btn_attack_Click;
            // 
            // dragon_attack
            // 
            dragon_attack.AutoSize = true;
            dragon_attack.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            dragon_attack.ForeColor = Color.Black;
            dragon_attack.Location = new Point(497, 206);
            dragon_attack.Name = "dragon_attack";
            dragon_attack.Size = new Size(45, 23);
            dragon_attack.TabIndex = 18;
            dragon_attack.Text = "Rock";
            dragon_attack.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbl_attack
            // 
            lbl_attack.AutoSize = true;
            lbl_attack.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_attack.ForeColor = Color.Black;
            lbl_attack.Location = new Point(219, 206);
            lbl_attack.Name = "lbl_attack";
            lbl_attack.Size = new Size(45, 23);
            lbl_attack.TabIndex = 17;
            lbl_attack.Text = "Rock";
            lbl_attack.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // cb_attacks
            // 
            cb_attacks.FormattingEnabled = true;
            cb_attacks.Items.AddRange(new object[] { "Rock", "Paper", "Scissor" });
            cb_attacks.Location = new Point(235, 284);
            cb_attacks.Name = "cb_attacks";
            cb_attacks.Size = new Size(199, 23);
            cb_attacks.TabIndex = 16;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Comic Sans MS", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label24.ForeColor = Color.Black;
            label24.Location = new Point(338, 194);
            label24.Name = "label24";
            label24.Size = new Size(48, 35);
            label24.TabIndex = 15;
            label24.Text = "VS";
            label24.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label23.ForeColor = Color.Red;
            label23.Location = new Point(426, 158);
            label23.Name = "label23";
            label23.Size = new Size(175, 23);
            label23.TabIndex = 14;
            label23.Text = "Red Dragon's Attack\r\n";
            label23.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label22.ForeColor = Color.Black;
            label22.Location = new Point(188, 158);
            label22.Name = "label22";
            label22.Size = new Size(105, 23);
            label22.TabIndex = 13;
            label22.Text = "Your Attack";
            label22.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label21.ForeColor = Color.Black;
            label21.Location = new Point(168, 247);
            label21.Name = "label21";
            label21.Size = new Size(417, 23);
            label21.TabIndex = 12;
            label21.Text = "(Select you attack by choosing the drop down menu)";
            label21.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label20.ForeColor = Color.Black;
            label20.Location = new Point(60, 97);
            label20.Name = "label20";
            label20.Size = new Size(661, 46);
            label20.TabIndex = 11;
            label20.Text = "Don't just think this is a normal game, remember you are still in your fourth trial.\r\nIf you win 3 times I'll let you pass, but If you fail I'll burn all of your chances.";
            label20.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label19.ForeColor = Color.Black;
            label19.Location = new Point(338, 62);
            label19.Name = "label19";
            label19.Size = new Size(383, 23);
            label19.TabIndex = 10;
            label19.Text = "I challenge you to a Rock, Paper, Scissor Game";
            label19.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label18.ForeColor = Color.Black;
            label18.Location = new Point(108, 62);
            label18.Name = "label18";
            label18.Size = new Size(224, 23);
            label18.TabIndex = 9;
            label18.Text = "So you are the new hero...";
            label18.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label17.ForeColor = Color.Red;
            label17.Location = new Point(6, 62);
            label17.Name = "label17";
            label17.Size = new Size(113, 23);
            label17.TabIndex = 8;
            label17.Text = "Red Dragon: \r\n";
            label17.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label16.ForeColor = Color.Red;
            label16.Location = new Point(6, 21);
            label16.Name = "label16";
            label16.Size = new Size(212, 23);
            label16.TabIndex = 7;
            label16.Text = "*A Red Dragon appeared*";
            label16.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // trial_5
            // 
            trial_5.Controls.Add(tb_answer);
            trial_5.Controls.Add(btn_finish);
            trial_5.Controls.Add(label28);
            trial_5.Controls.Add(label27);
            trial_5.Location = new Point(4, 24);
            trial_5.Name = "trial_5";
            trial_5.Padding = new Padding(3);
            trial_5.Size = new Size(760, 323);
            trial_5.TabIndex = 4;
            trial_5.Text = "Trial 5";
            trial_5.UseVisualStyleBackColor = true;
            // 
            // btn_finish
            // 
            btn_finish.FlatStyle = FlatStyle.Flat;
            btn_finish.Font = new Font("Comic Sans MS", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btn_finish.ForeColor = SystemColors.ActiveCaptionText;
            btn_finish.Location = new Point(581, 266);
            btn_finish.Name = "btn_finish";
            btn_finish.Size = new Size(75, 34);
            btn_finish.TabIndex = 20;
            btn_finish.Text = "Submit";
            btn_finish.UseVisualStyleBackColor = true;
            btn_finish.Click += btn_finish_Click;
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label28.ForeColor = Color.Black;
            label28.Location = new Point(361, 232);
            label28.Name = "label28";
            label28.Size = new Size(193, 23);
            label28.TabIndex = 11;
            label28.Text = "Answer your final trial:";
            label28.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label27.ForeColor = Color.Black;
            label27.Location = new Point(32, 54);
            label27.Name = "label27";
            label27.Size = new Size(294, 161);
            label27.TabIndex = 10;
            label27.Text = "Making every trial there's an end,\r\nEvery journey makes you bend.\r\nEverywhere you should be,\r\nSeeking for the one legitimate key.\r\n\r\nStarting characters of every trials,\r\nwill it be?\r\n";
            label27.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Comic Sans MS", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(570, 9);
            label1.Name = "label1";
            label1.Size = new Size(102, 27);
            label1.TabIndex = 5;
            label1.Text = "Chances: ";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblChances
            // 
            lblChances.AutoSize = true;
            lblChances.Font = new Font("Comic Sans MS", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            lblChances.Location = new Point(660, 9);
            lblChances.Name = "lblChances";
            lblChances.Size = new Size(36, 27);
            lblChances.TabIndex = 6;
            lblChances.Text = "10";
            lblChances.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tb_answer
            // 
            tb_answer.Location = new Point(361, 272);
            tb_answer.Name = "tb_answer";
            tb_answer.Size = new Size(204, 23);
            tb_answer.TabIndex = 21;
            // 
            // T_1_1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(802, 410);
            Controls.Add(lblChances);
            Controls.Add(label1);
            Controls.Add(trial_board);
            FormBorderStyle = FormBorderStyle.None;
            Name = "T_1_1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "T_1_1";
            Load += T_1_1_Load;
            trial_board.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            trial_2.ResumeLayout(false);
            trial_2.PerformLayout();
            trial_3.ResumeLayout(false);
            trial_3.PerformLayout();
            trial_4.ResumeLayout(false);
            trial_4.PerformLayout();
            trial_5.ResumeLayout(false);
            trial_5.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TabControl trial_board;
        private TabPage tabPage1;
        private TabPage trial_2;
        private Label label2;
        private TextBox t1_answer;
        private Label trial_1;
        private Label label1;
        private Label lblChances;
        private Button btn_submit;
        private Label lbl_comment;
        private Button btn_sub;
        private Label label8;
        private TextBox t2_answer;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private TabPage trial_3;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label lbl_t3_answer2;
        private Button btn_t3_next;
        private Label lbl_t3_answer;
        private Button btn_done;
        private TabPage trial_4;
        private Label dragon_attack;
        private Label lbl_attack;
        private ComboBox cb_attacks;
        private Label label24;
        private Label label23;
        private Label label22;
        private Label label21;
        private Label label20;
        private Label label19;
        private Label label18;
        private Label label17;
        private Label label16;
        private TabPage trial_5;
        private ComboBox comboBox2;
        private Label label28;
        private Label label27;
        private Button btn_attack;
        private Label player_score;
        private Button btn_finish;
        private Label dragon_score;
        private TextBox tb_answer;
    }
}